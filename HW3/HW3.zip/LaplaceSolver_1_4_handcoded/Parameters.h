#pragma once

#define XDIM 256
#define YDIM 256
#define ZDIM 256

constexpr int kMax = 1000;
constexpr float nuMax = 1e-3;
